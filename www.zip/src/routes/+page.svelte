<div class="wrapper">
	<div class="container">
		<h1 class="title">chle</h1>
		<p class="subtitle">a cool guy</p>

		<div class="links">
			<a href="https://github.com/chlewtf" target="_blank">GitHub</a>
			<a href="https://twitter.com/chlewtf" target="_blank">Twitter</a>
			<a href="mailto:hello@chle.wtf">Email</a>
		</div>
	</div>
</div>
